package com.example.lapor_kehilangan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
